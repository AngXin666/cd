"""
数据库连接模块
管理 SQLite/PostgreSQL 数据库连接和会话

支持的数据库：
- SQLite（开发环境）：sqlite:///./data/app.db
- PostgreSQL（生产环境）：postgresql://user:password@host:port/database
"""

from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy.pool import QueuePool, StaticPool
from config import get_settings, get_database_url
import os
import logging

# 配置日志
logger = logging.getLogger(__name__)

# 获取配置
settings = get_settings()

# 获取数据库 URL
database_url = get_database_url()


def create_database_engine():
    """
    创建数据库引擎
    根据数据库类型（SQLite/PostgreSQL）配置不同的连接参数

    Returns:
        Engine: SQLAlchemy 数据库引擎
    """
    # 连接参数
    connect_args = {}
    engine_kwargs = {
        "echo": settings.debug,  # 开发模式下打印 SQL
    }

    if database_url.startswith("sqlite"):
        # SQLite 配置
        # check_same_thread=False 以支持多线程
        connect_args["check_same_thread"] = False
        # SQLite 使用 StaticPool（单连接）
        engine_kwargs["poolclass"] = StaticPool
        # 确保数据目录存在
        os.makedirs("data", exist_ok=True)
        logger.info(f"使用 SQLite 数据库: {database_url}")

    elif database_url.startswith("postgresql"):
        # PostgreSQL 配置
        # 使用连接池
        engine_kwargs["poolclass"] = QueuePool
        engine_kwargs["pool_size"] = settings.db_pool_size
        engine_kwargs["max_overflow"] = settings.db_max_overflow
        engine_kwargs["pool_timeout"] = settings.db_pool_timeout
        engine_kwargs["pool_pre_ping"] = True  # 连接前检查连接是否有效
        logger.info(f"使用 PostgreSQL 数据库，连接池大小: {settings.db_pool_size}")

    else:
        # 其他数据库（如 MySQL）
        logger.warning(f"未知数据库类型: {database_url}")

    return create_engine(
        database_url,
        connect_args=connect_args,
        **engine_kwargs
    )


# 创建数据库引擎（全局单例）
engine = create_database_engine()


def create_db_and_tables():
    """
    创建数据库和所有表
    在应用启动时调用

    注意：
    - SQLite：自动创建数据库文件
    - PostgreSQL：需要先创建数据库
    """
    try:
        SQLModel.metadata.create_all(engine)
        logger.info("数据库表创建成功")
    except Exception as e:
        logger.error(f"数据库表创建失败: {e}")
        raise


def get_session():
    """
    获取数据库会话
    用于 FastAPI 依赖注入

    Yields:
        Session: 数据库会话对象

    Example:
        @app.get("/users")
        def get_users(session: Session = Depends(get_session)):
            return session.exec(select(User)).all()
    """
    with Session(engine) as session:
        yield session


def check_database_connection() -> bool:
    """
    检查数据库连接是否正常
    用于健康检查

    Returns:
        bool: True 表示连接正常，False 表示连接失败
    """
    try:
        with Session(engine) as session:
            # 执行简单查询测试连接
            session.execute("SELECT 1")
        return True
    except Exception as e:
        logger.error(f"数据库连接检查失败: {e}")
        return False


def migrate_warehouse_types():
    """
    数据迁移：为现有仓库设置默认的 warehouse_type 值
    
    此函数用于将现有仓库数据迁移到新的仓库类型系统。
    所有没有设置 warehouse_type 的仓库将被设置为默认值 "piece"（计件类型）。
    
    此迁移是幂等的，可以安全地多次执行：
    - 如果仓库已有 warehouse_type 值，则不会被修改
    - 如果仓库的 warehouse_type 为 NULL 或空，则设置为 "piece"
    
    Returns:
        int: 被迁移的仓库数量
    
    Example:
        >>> count = migrate_warehouse_types()
        >>> print(f"迁移了 {count} 个仓库")
    
    Requirements: 5.1 - 数据迁移
    """
    from sqlmodel import text
    
    try:
        with Session(engine) as session:
            # 使用原生 SQL 更新，确保兼容 SQLite 和 PostgreSQL
            # 只更新 warehouse_type 为 NULL 或空字符串的记录
            result = session.execute(
                text("""
                    UPDATE warehouses 
                    SET warehouse_type = 'piece' 
                    WHERE warehouse_type IS NULL 
                       OR warehouse_type = ''
                """)
            )
            
            # 获取受影响的行数
            migrated_count = result.rowcount
            
            # 提交事务
            session.commit()
            
            if migrated_count > 0:
                logger.info(f"仓库类型迁移完成：{migrated_count} 个仓库已设置为默认类型 'piece'")
            else:
                logger.info("仓库类型迁移：没有需要迁移的仓库")
            
            return migrated_count
            
    except Exception as e:
        logger.error(f"仓库类型迁移失败: {e}")
        raise


def migrate_app_versions_table():
    """
    数据迁移：确保 app_versions 表存在并具有正确的结构
    
    此函数用于创建或验证 app_versions 表的存在。
    由于 SQLModel 的 create_all 会自动创建表，此函数主要用于：
    1. 验证表是否存在
    2. 记录迁移日志
    3. 为未来可能的表结构变更提供扩展点
    
    此迁移是幂等的，可以安全地多次执行。
    
    Returns:
        bool: True 表示表存在或创建成功
    
    Example:
        >>> success = migrate_app_versions_table()
        >>> print(f"app_versions 表迁移: {'成功' if success else '失败'}")
    
    Requirements: 7.1 - 版本信息持久化
    """
    from sqlmodel import text
    
    try:
        with Session(engine) as session:
            # 检查表是否存在
            # SQLite 和 PostgreSQL 使用不同的查询方式
            if database_url.startswith("sqlite"):
                result = session.execute(
                    text("SELECT name FROM sqlite_master WHERE type='table' AND name='app_versions'")
                )
            else:
                # PostgreSQL
                result = session.execute(
                    text("SELECT tablename FROM pg_tables WHERE tablename='app_versions'")
                )
            
            table_exists = result.fetchone() is not None
            
            if table_exists:
                logger.info("app_versions 表已存在，跳过创建")
            else:
                # 表不存在，SQLModel.metadata.create_all 应该已经创建了
                # 这里记录警告，因为正常情况下表应该已经存在
                logger.warning("app_versions 表不存在，将由 SQLModel 自动创建")
            
            return True
            
    except Exception as e:
        logger.error(f"app_versions 表迁移检查失败: {e}")
        raise


def run_migrations():
    """
    运行所有数据库迁移
    
    此函数在应用启动时调用，执行所有必要的数据迁移。
    所有迁移都是幂等的，可以安全地多次执行。
    
    当前包含的迁移：
    1. migrate_warehouse_types - 为现有仓库设置默认类型
    2. migrate_app_versions_table - 确保 app_versions 表存在
    
    Example:
        >>> run_migrations()
    
    Requirements: 5.1 - 数据迁移, 7.1 - 版本信息持久化
    """
    logger.info("开始执行数据库迁移...")
    
    try:
        # 迁移 1: 仓库类型
        migrate_warehouse_types()
        
        # 迁移 2: 应用版本表
        migrate_app_versions_table()
        
        logger.info("所有数据库迁移执行完成")
        
    except Exception as e:
        logger.error(f"数据库迁移执行失败: {e}")
        raise
